package model;

public class City {

}