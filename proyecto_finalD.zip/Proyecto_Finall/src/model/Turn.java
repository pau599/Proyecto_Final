package model;

public class Turn implements Comparable<Turn> {

	@Override
	public int compareTo(Turn o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
